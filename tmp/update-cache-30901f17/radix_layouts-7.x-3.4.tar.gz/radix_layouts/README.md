Radix Layouts
===
Responsive Panels layouts for Panopoly and the Radix theme.

## Features

* Responsive out of the box
* Works with Panopoly, Panels IPE, and Panelizer
* Easily extendable to support new layouts
* Support for Responsive utility classes (You can easily hide and show panes based on mobile, tablet or desktop viewports)

## Which version?

* For Radix 2.x, use Radix Layouts 7.x-2.x.
* For Radix 3.x, use Radix Layouts 7.x-3.x.
